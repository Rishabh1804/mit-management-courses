# CLAUDE.md

You are working inside the MIT Management Courses repo.

This repo turns MIT management and executive education course material into reusable skills, tools, workflows, and business applications.

## Working Style

Do not treat course material as passive notes.

For every course, extract:

1. Core concepts
2. Practical frameworks
3. Reusable decision tools
4. Reflection exercises
5. Business applications
6. AI agent skills
7. Prompts and workflows

## Repository Relationship

This repo is parallel to the MSc Data Science / AI repo.

The MSc repo builds technical capabilities.
This repo builds management, leadership, and organizational capabilities.

When relevant, connect management concepts to practical business systems, dashboards, team workflows, founder decisions, and operating routines.

## Standard Course Processing Flow

For every course:

1. Read the course overview
2. Create a course brief
3. Build a module map
4. Extract frameworks
5. Convert frameworks into tools
6. Create assignments
7. Create project applications
8. Create an AI skill card
9. Add the skill to SKILLS_REGISTRY.md

## Output Philosophy

Every concept should eventually become one or more of:

- A prompt
- A checklist
- A decision framework
- A diagnostic tool
- A meeting format
- A leadership behavior
- A project workflow
- A reusable AI skill

## Current Active Course

Course: Unlocking Your Leadership Signature

Main goal:
Help the user identify, articulate, and apply their personal leadership signature in business, family business, team management, delegation, communication, and organizational transformation.

## Important Instruction

When working on this repo, always ask:

“How can this course make the user better at running, organizing, scaling, or leading real projects?”
