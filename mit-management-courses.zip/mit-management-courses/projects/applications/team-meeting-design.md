# Team Meeting Design Application

Translate leadership signature into meeting formats.

## Meeting Design

- Purpose
- Decision rights
- Discussion rules
- Accountability owner
- Follow-up rhythm
