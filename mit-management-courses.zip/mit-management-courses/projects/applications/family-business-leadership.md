# Family Business Leadership Application

Use leadership signature work to clarify role, authority, communication, and accountability in a family business.

## Questions

- What role do I naturally play in the family business?
- Where does family history affect business decision-making?
- Which conflicts are business conflicts vs family-system conflicts?
- What leadership behavior would improve trust and clarity?
