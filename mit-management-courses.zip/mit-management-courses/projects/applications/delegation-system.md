# Delegation System Application

Use immunity-to-change and provisional self experiments to improve delegation.

## Delegation Rules

- Define task
- Define owner
- Define acceptance criteria
- Define review point
- Avoid taking back ownership unless required
