# Conflict Resolution Application

Use leadership signature to handle conflict consciously.

## Process

1. Identify the real conflict.
2. Separate facts, interpretations, and emotions.
3. Identify the leadership pattern being triggered.
4. Choose a deliberate response.
5. Create agreement and follow-up.
