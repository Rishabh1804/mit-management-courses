# Founder Leadership Style Application

Use the leadership signature to define how the founder leads the business.

## Founder Operating Style

- How I create clarity
- How I make decisions
- How I delegate
- How I review work
- How I handle conflict
- How I develop people
