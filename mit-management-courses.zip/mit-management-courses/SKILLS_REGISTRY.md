# Skills Registry

This file tracks reusable skills created from MIT management courses.

## Active Skills

### Leadership Signature

Source course: Unlocking Your Leadership Signature  
Status: In development  
Skill path: `skills/leadership-signature/`

Purpose:
Help identify, articulate, and apply a person’s unique leadership style across team leadership, business operations, communication, delegation, and organizational change.

Primary outputs:

- Leadership signature statement
- Leadership story
- Immunity-to-change map
- Development plan
- Team leadership application
- Founder/manager operating style

## Future Skills

- Strategic decision-making
- Organizational design
- Innovation leadership
- Negotiation
- System leadership
- Execution management
