# Reflections

Use this file for ongoing reflections during the course.
