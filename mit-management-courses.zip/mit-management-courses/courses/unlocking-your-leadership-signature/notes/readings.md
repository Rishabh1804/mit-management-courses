# Readings Notes

## Mentioned Faculty Work

- X-Teams: How to Build Teams That Lead, Innovate, and Succeed
- In Praise of the Incomplete Leader
- Nimble Leadership: Walking the Line between Creativity and Chaos

## Notes

Add reading summaries here.
