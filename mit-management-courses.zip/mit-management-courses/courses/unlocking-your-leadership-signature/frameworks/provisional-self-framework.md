# Provisional Self Framework

## Purpose

Experiment with new leadership behaviors before fully adopting them.

## Core Idea

Instead of forcing a permanent identity change, create temporary leadership experiments.

## Process

1. Identify the leadership behavior to develop.
2. Choose a role model or reference behavior.
3. Design a small experiment.
4. Try the behavior in a low-risk setting.
5. Collect feedback.
6. Keep, adapt, or discard the behavior.

## Experiment Template

- Behavior to test:
- Situation:
- Role model/reference:
- What I will do differently:
- What I expect to happen:
- What actually happened:
- What I learned:
- Keep/adapt/discard:
