# Family Systems Model

## Purpose

Use past family and social systems to understand current leadership patterns.

## Core Idea

Leadership behaviors are often shaped by early systems: family roles, conflict patterns, authority dynamics, responsibility expectations, and communication norms.

## Reflection Areas

- Role I played in my family or early environment
- How authority was handled
- How conflict was handled
- What responsibility I learned to carry
- What emotions were rewarded or discouraged
- How these patterns appear in my current leadership

## Tool Output

A map connecting past pattern → current leadership behavior → helpful impact → limiting impact → conscious choice.
