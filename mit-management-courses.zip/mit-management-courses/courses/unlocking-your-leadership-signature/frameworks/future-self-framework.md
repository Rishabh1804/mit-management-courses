# Future Self Framework

## Purpose

Define the leader the user wants to become and create milestones toward that identity.

## Future Self Prompts

- What kind of leader do I want to be known as?
- What should my team feel after interacting with me?
- What should I stop doing as a leader?
- What should I start doing consistently?
- What responsibilities should I grow into?
- What systems will help me become this leader?

## Output Template

In 12 months, I want to be the kind of leader who:

- Creates clarity by...
- Builds trust by...
- Makes decisions by...
- Develops people by...
- Handles conflict by...
- Measures progress by...
