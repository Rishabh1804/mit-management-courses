# Leadership Signature

## Definition

A leadership signature is the distinctive way a person leads based on experience, personality, strengths, values, and learned patterns.

## Core Question

What is the best way for me to lead from who I actually am?

## Diagnostic Prompts

- When do people naturally look to me for leadership?
- What leadership behaviors feel natural to me?
- What leadership behaviors feel forced?
- What do people trust me for?
- What do I avoid when leading?
- What pattern shows up repeatedly in my leadership stories?

## Output Template

My leadership signature is:

> I lead by [primary behavior], especially when [context]. People experience me as [impact]. My edge is [strength], and my growth area is [development need].

## Business Applications

- Founder role clarity
- Manager communication style
- Delegation style
- Team culture design
- Leadership story for employees and partners
