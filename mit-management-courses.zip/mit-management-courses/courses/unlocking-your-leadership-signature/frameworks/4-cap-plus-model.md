# 4-CAP+ Model

## Core Capabilities

The course references the 4-CAP+ model as including:

1. Visioning
2. Relating
3. Inventing
4. Sensemaking

## Practical Translation

### Visioning
Creating a compelling direction.

### Relating
Building trust, connection, and commitment with people.

### Inventing
Creating new processes, structures, and solutions.

### Sensemaking
Understanding complex situations and helping others interpret them.

## Leadership Diagnostic

Score each capability from 1 to 5:

| Capability | Score | Evidence | Improvement Action |
|---|---:|---|---|
| Visioning |  |  |  |
| Relating |  |  |  |
| Inventing |  |  |  |
| Sensemaking |  |  |  |

## Business Applications

- Strategy meetings
- Team alignment
- Operating system design
- Crisis response
- New initiative design
