# Immunity to Change

## Purpose

Diagnose why a sincere leadership goal does not translate into behavior change.

## Core Structure

| Column | Question |
|---|---|
| Improvement Goal | What do I want to change? |
| Current Behaviors | What am I doing or not doing instead? |
| Hidden Competing Commitments | What am I secretly committed to protecting? |
| Big Assumptions | What belief makes the hidden commitment feel necessary? |
| Tests | What small experiment can test whether the assumption is true? |

## Example

Goal: Delegate more effectively.  
Current behavior: I keep reviewing everything myself.  
Hidden commitment: I am committed to avoiding mistakes that reflect badly on me.  
Big assumption: If I do not personally check everything, quality will collapse.  
Test: Delegate one defined task with clear acceptance criteria and review only the final output.

## Business Applications

- Founder bottleneck removal
- Delegation
- Conflict avoidance
- Decision rights
- Accountability systems
