# Leadership Development Plan

## 12-Month Leadership Goal

[Write goal]

## Development Areas

| Area | Current Pattern | Desired Pattern | Practice | Review Rhythm |
|---|---|---|---|---|
|  |  |  |  |  |

## Monthly Milestones

| Month | Milestone | Evidence |
|---|---|---|
| 1 |  |  |
| 2 |  |  |
| 3 |  |  |
| 6 |  |  |
| 12 |  |  |
