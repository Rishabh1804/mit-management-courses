# Leadership Signature Draft

## Draft Statement

My leadership signature is:

> [Draft here]

## Evidence

- Story 1:
- Story 2:
- Story 3:

## Strengths

- 

## Growth Areas

- 
