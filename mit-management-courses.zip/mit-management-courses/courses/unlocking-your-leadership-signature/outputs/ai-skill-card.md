# AI Skill Card: Leadership Signature

## Skill Name

Leadership Signature Builder

## Purpose

Help a user identify, articulate, and apply their unique leadership style.

## Use When

- The user is trying to become a better leader.
- The user is managing a family business, team, or project.
- The user feels blocked in delegation, conflict, accountability, or communication.
- The user wants a leadership story, self-assessment, or development plan.

## Inputs

- Leadership context
- Past leadership stories
- Current responsibilities
- Team challenges
- Desired future leadership identity

## Process

1. Identify recurring leadership strengths.
2. Map past systems and leadership patterns.
3. Analyze capabilities using 4-CAP+.
4. Diagnose immunity to change.
5. Design provisional self experiments.
6. Draft leadership story.
7. Convert into practical leadership development plan.

## Outputs

- Leadership signature statement
- Leadership story
- Immunity map
- Behavior experiment
- Development plan
- Business application recommendations
