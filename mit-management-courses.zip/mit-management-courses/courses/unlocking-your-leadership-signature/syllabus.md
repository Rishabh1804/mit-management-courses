# Syllabus: Unlocking Your Leadership Signature

## Module 1: Identifying Your Leadership Signature

Explore your leadership signature and the leadership signatures of others. Use xCards-style reflection to identify patterns, strengths, and themes.

## Module 2: Analyzing the Past to Become a Better Leader in the Future

Use the family systems model to understand how past experiences shape current leadership behavior. Begin drafting leadership stories and gathering feedback.

## Module 3: Analyzing Your Developed Self

Analyze crucibles and developmental stages. Introduce the 4-CAP+ model: visioning, relating, inventing, and sensemaking. Complete a draft leadership story.

## Module 4: Diagnosing Immunity to Change

Apply the Immunity to Change framework to a specific leadership goal. Identify hidden commitments, assumptions, and barriers to change.

## Module 5: First Steps to Developing as a Leader

Study the Authenticity Paradox and cognitive impediments. Use the Provisional Self Framework to experiment with new leadership behaviors.

## Module 6: Being the Leader of Tomorrow: Your Future Self

Refine your future self, identify milestones, and polish the final leadership story. Translate the course into next steps for leadership development.
