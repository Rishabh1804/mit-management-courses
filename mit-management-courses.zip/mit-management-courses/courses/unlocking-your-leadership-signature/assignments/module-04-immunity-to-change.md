# Module 4 Assignment: Immunity to Change Map

## Goal

Diagnose one leadership goal that is blocked by hidden commitments or assumptions.

## Exercises

1. Choose one leadership improvement goal.
2. List current behaviors that contradict the goal.
3. Identify hidden competing commitments.
4. Identify big assumptions.
5. Design one small test.

## Output

Completed immunity-to-change map.
