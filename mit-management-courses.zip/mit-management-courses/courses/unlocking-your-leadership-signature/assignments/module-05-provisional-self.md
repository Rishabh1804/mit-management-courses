# Module 5 Assignment: Provisional Self Experiment

## Goal

Experiment with one new leadership behavior.

## Exercises

1. Choose one behavior that feels important but unnatural.
2. Identify a role model or reference.
3. Design a low-risk experiment.
4. Run the experiment.
5. Capture feedback and learning.

## Output

One leadership behavior experiment report.
