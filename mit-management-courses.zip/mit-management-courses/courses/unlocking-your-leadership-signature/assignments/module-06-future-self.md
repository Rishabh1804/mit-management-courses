# Module 6 Assignment: Future Self and Final Story

## Goal

Define your future leadership self and finalize your leadership story.

## Exercises

1. Describe your desired future leadership identity.
2. Identify 3 milestones.
3. Identify 3 behaviors to stop.
4. Identify 3 behaviors to start.
5. Polish your leadership story.

## Output

Final leadership story and 12-month leadership development plan.
