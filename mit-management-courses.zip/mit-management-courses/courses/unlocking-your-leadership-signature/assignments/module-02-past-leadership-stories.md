# Module 2 Assignment: Past Leadership Stories

## Goal

Connect past experiences to present leadership behavior.

## Exercises

1. Identify three early life systems that shaped you.
2. Describe your role in each system.
3. Identify one helpful leadership pattern from each.
4. Identify one limiting leadership pattern from each.
5. Write a short leadership story from your past.

## Output

A past-to-present leadership pattern map.
