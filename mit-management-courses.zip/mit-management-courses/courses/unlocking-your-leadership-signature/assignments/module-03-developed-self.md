# Module 3 Assignment: Developed Self and 4-CAP+

## Goal

Analyze your developed leadership self using crucibles and the 4-CAP+ model.

## Exercises

1. Identify two crucible experiences.
2. Explain how each changed your leadership style.
3. Score yourself on visioning, relating, inventing, and sensemaking.
4. Identify your strongest and weakest capability.
5. Draft a leadership story using these insights.

## Output

Leadership story draft v1.
