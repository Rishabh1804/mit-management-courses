# Module 1 Assignment: Identify Your Leadership Signature

## Goal

Create a first-pass leadership signature statement.

## Exercises

1. List five moments where you naturally led others.
2. List five moments where leadership felt difficult or unnatural.
3. Identify recurring strengths.
4. Identify recurring avoidance patterns.
5. Draft your leadership signature statement.

## Output

A one-paragraph leadership signature draft.
