# Unlocking Your Leadership Signature

This course folder converts the MIT Sloan Executive Education program *Unlocking Your Leadership Signature* into a practical leadership capability system.

## Course Purpose

The course is designed to help leaders identify, develop, and apply their unique leadership signature. The central output is a leadership story and development plan that connects past experience, current strengths, internal barriers, and future leadership goals.

## Repo Output

This folder will produce:

- Course brief
- Syllabus
- Module map
- Framework notes
- Assignments
- Leadership story drafts
- Development plan
- AI skill card
