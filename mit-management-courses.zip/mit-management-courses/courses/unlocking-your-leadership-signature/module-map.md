# Module Map

| Module | Theme | Frameworks | Main Output | Business Use |
|---|---|---|---|---|
| 1 | Leadership Signature | xCards-style identity reflection | Initial leadership signature notes | Understand default leadership style |
| 2 | Past and Family Systems | Family systems model | Past leadership stories | Understand inherited patterns |
| 3 | Developed Self | Crucibles, 4-CAP+ | Leadership story draft | Identify strengths and gaps |
| 4 | Immunity to Change | Immunity map | Change diagnosis | Remove internal blockers |
| 5 | Leader Development | Authenticity Paradox, Provisional Self | Experiment plan | Try new behaviors safely |
| 6 | Future Self | Future self / milestones | Final leadership story | Build leadership roadmap |
