# Immunity Map Template

| Improvement Goal | Current Behaviors | Hidden Competing Commitments | Big Assumptions | Small Test |
|---|---|---|---|---|
|  |  |  |  |  |
