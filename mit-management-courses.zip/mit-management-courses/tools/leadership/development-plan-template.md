# Leadership Development Plan Template

## Leadership Goal

[Write goal]

## Current Pattern

[Write current pattern]

## Desired Pattern

[Write desired pattern]

## Weekly Practice

[Write practice]

## Feedback Source

[Write source]

## Review Rhythm

[Weekly/monthly review]
