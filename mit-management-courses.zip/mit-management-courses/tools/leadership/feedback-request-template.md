# Feedback Request Template

Hi [Name],

I am working on understanding and improving my leadership style. Could you share brief feedback on:

1. When have you seen me lead at my best?
2. What do you think people rely on me for?
3. What is one leadership behavior I should improve?
4. What kind of leader do you think I could become?

Thank you.
