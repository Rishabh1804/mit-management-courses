# Leadership Signature Assessment

## Step 1: Leadership Moments

List 5 moments where you led well.

## Step 2: Pattern Extraction

For each moment, identify:

- Context
- Your behavior
- Team response
- Result
- Strength demonstrated

## Step 3: Draft Signature

Use the leadership signature statement template.
