# Leadership Story Builder

## Story Sections

1. My starting point
2. The experiences that shaped me
3. What I learned about people and responsibility
4. How I lead today
5. What I am learning to change
6. The leader I am becoming
7. My commitment to my team/business
