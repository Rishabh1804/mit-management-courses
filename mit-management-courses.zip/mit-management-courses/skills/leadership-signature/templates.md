# Leadership Signature Templates

## Leadership Signature Statement

I lead by [behavior/strength], especially in [context]. People experience me as [impact]. My edge is [strength]. My growth area is [growth area]. I am becoming a leader who [future identity].

## Leadership Story Outline

1. Origin
2. Crucible
3. Pattern
4. Strength
5. Limitation
6. Future self
7. Commitment

## Development Plan

| Goal | Behavior | Practice | Feedback Source | Review Date |
|---|---|---|---|---|
|  |  |  |  |  |
