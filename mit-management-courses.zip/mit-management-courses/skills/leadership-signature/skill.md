# Skill: Leadership Signature Builder

## What This Skill Does

This skill converts reflection on personal history, current leadership behavior, strengths, and blockers into a usable leadership signature and development plan.

## When To Use

Use this skill when a user is:

- Becoming a founder, manager, or team leader
- Struggling with delegation or accountability
- Facing leadership conflict
- Trying to communicate their leadership philosophy
- Designing a leadership development plan

## Workflow

1. Gather leadership stories.
2. Identify repeated patterns.
3. Map past systems.
4. Score 4-CAP+ capabilities.
5. Diagnose immunity to change.
6. Design provisional experiments.
7. Draft and refine the leadership story.
8. Convert insights into operating behaviors.
