# Leadership Signature Prompts

## Discovery Prompt

Help me identify my leadership signature. Ask me about leadership moments, strengths, difficult patterns, feedback I have received, and the kind of leader I want to become.

## Immunity Prompt

Help me create an immunity-to-change map for this leadership goal: [goal]. Identify my current behaviors, hidden competing commitments, big assumptions, and small tests.

## Story Prompt

Help me write a leadership story that connects my past experiences, current strengths, growth areas, and future leadership identity.

## Business Application Prompt

Apply my leadership signature to this business challenge: [challenge]. Give me specific behaviors, meeting formats, delegation rules, and communication practices.
