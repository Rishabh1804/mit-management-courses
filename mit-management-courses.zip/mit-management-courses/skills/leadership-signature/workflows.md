# Leadership Signature Workflows

## Workflow 1: Leadership Signature Discovery

1. Collect 3–5 leadership stories.
2. Extract patterns.
3. Identify strengths and shadows.
4. Draft signature.
5. Ask for feedback.
6. Revise.

## Workflow 2: Delegation Breakthrough

1. Define delegation goal.
2. Map immunity to change.
3. Identify assumption.
4. Design small delegation test.
5. Review outcome.
6. Update delegation system.

## Workflow 3: Team Leadership Translation

1. Define team problem.
2. Identify signature strengths relevant to the problem.
3. Identify signature risks.
4. Design communication rhythm.
5. Define accountability mechanism.
6. Review weekly.
