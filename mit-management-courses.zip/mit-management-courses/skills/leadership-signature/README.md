# Leadership Signature Skill

This skill helps identify, articulate, and apply a person's unique leadership style.

## Main Outputs

- Leadership signature statement
- Leadership story
- Immunity-to-change map
- Provisional self experiment
- Leadership development plan
